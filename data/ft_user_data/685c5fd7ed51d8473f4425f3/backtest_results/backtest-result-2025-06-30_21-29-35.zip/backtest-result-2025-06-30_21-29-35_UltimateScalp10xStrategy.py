from freqtrade.strategy import IStrategy, merge_informative_pair
from typing import Dict, List, Optional, Tuple
from freqtrade.strategy.interface import ListPairsWithTimeframes # type: ignore
from freqtrade.constants import PairWithTimeframe # type: ignore
from datetime import datetime, timedelta
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas_ta as p_ta
from pandas import DataFrame
from functools import reduce
import numpy as np

class UltimateScalp10xStrategy(IStrategy):
    timeframe = '1m'
    informative_timeframe = '5m'
    
    stoploss = -0.015
    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.01
    minimal_roi = {
        "0": 0.015,
        "1": 0.01,
        "2": 0.005,
        "3": 0.001
    }

    leverage_num = 10
    risk_per_trade = 0.03
    cooldown_minutes = 2
    last_exit_time = None

    volume_lookback = 20
    volume_zscore_threshold = 2.0
    adx_threshold = 25
    atr_threshold = 0.02

    slippage = 0.001  # 0.1% slippage
    exchange_fee = 0.001  # 0.1% fee per trade (Binance: 0.1%)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Calculate various indicators
        dataframe['sma_short'] = ta.SMA(dataframe, timeperiod=5)
        dataframe['sma_long'] = ta.SMA(dataframe, timeperiod=10)
        dataframe['ema_short'] = ta.EMA(dataframe, timeperiod=5)
        dataframe['ema_long'] = ta.EMA(dataframe, timeperiod=10)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['adx'] = ta.ADX(dataframe)
        dataframe['atr'] = ta.ATR(dataframe)

        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)

        dataframe['bb_lowerband'] = bollinger['lower']
        dataframe['bb_middleband'] = bollinger['mid']
        dataframe['bb_upperband'] = bollinger['upper']

        # Volume indicators
        dataframe['volume_mean'] = dataframe['volume'].rolling(self.volume_lookback).mean()
        dataframe['volume_std'] = dataframe['volume'].rolling(self.volume_lookback).std()
        dataframe['volume_zscore'] = (dataframe['volume'] - dataframe['volume_mean']) / dataframe['volume_std']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] > dataframe['sma_long']) &
            (dataframe['rsi'] < 30) &
            (dataframe['volume_zscore'] > self.volume_zscore_threshold) &
            (dataframe['adx'] > self.adx_threshold) &
            (dataframe['atr'] > self.atr_threshold) &
            (dataframe['volume'] > 0)  # Ensure there is volume
            , 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] < dataframe['sma_long']) &
            (dataframe['rsi'] > 70) &
            (dataframe['close'] < dataframe['bb_middleband']) & # Price below middle band
            (dataframe['close'] < dataframe['bb_upperband']) # Price below upper band
            , 'exit_long'] = 1
        return dataframe