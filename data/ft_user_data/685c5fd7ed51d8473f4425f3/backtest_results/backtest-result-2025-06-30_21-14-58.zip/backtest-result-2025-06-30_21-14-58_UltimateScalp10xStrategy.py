from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class UltimateScalp10xStrategy(IStrategy):
    timeframe = '1m'
    stoploss = -0.02
    minimal_roi = {
        "0": 0.02,
        "15": 0.01,
        "30": 0.005
    }
    trailing_stop = True
    trailing_stop_positive = 0.001
    trailing_stop_positive_offset = 0.01
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sma_short'] = ta.SMA(dataframe, timeperiod=5)
        dataframe['sma_long'] = ta.SMA(dataframe, timeperiod=10)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] > dataframe['sma_long']) &
            (dataframe['volume'] > 0)  # Ensure there is volume
            , 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] < dataframe['sma_long'])
            , 'exit_long'] = 1
        return dataframe