from freqtrade.strategy import IStrategy, DecimalParameter
from pandas import DataFrame
from datetime import datetime
from typing import Optional
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

import logging

class FixedRiskRewardLossV2(IStrategy):
    """
    FixedRiskRewardLossV2
    This strategy aims to implement a fixed risk-reward ratio with a dynamic stop-loss and take-profit.
    It uses EMA, RSI, ADX, ATR, and Volume MA indicators for entry and exit signals.
    """
    # Strategy interface version - allow new features to be introduced without breaking changes
    # Freqtrade will fail to load strategies that don't match the current interface version.
    strategy_version = 2
    # Strategy Settings
    # Strategy Settings
    timeframe = '5m'
    stake_currency = 'USDT'
    startup_candle_count: int = 30
    minimal_roi = {"0": 0.05}
    stoploss = -0.03

    # Hyperopt parameter for sell signal
    sell_signal_threshold = DecimalParameter(0.01, 0.1, default=0.05, space="sell", optimize=True, load=True)

    # Strategy parameters
    rsi_buy_threshold = DecimalParameter(50, 70, default=60, space='buy', optimize=True)
    adx_buy_threshold = DecimalParameter(15, 30, default=20, space='buy', optimize=True, load=True)

    # Custom stake sizing
    stake_percentage = DecimalParameter(0.01, 0.1, default=0.05, space="buy", optimize=True, load=True)
    min_account_balance = DecimalParameter(100, 500, default=100, space="buy", optimize=True, load=True)
    max_account_balance = DecimalParameter(10000, 50000, default=20000, space="buy", optimize=True, load=True)

    def __init__(self, config: dict) -> None:
        """
        Initializes the strategy with the given configuration.
        Args:
            config: A dictionary containing the strategy configuration.
        """
        super().__init__(config)
        self.validate_parameters()
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)

    def validate_parameters(self) -> None:
        """
        Validates the strategy parameters to ensure they are within acceptable ranges.
        Raises:
            ValueError: If any parameter is out of its valid range.
        """
        if not 0 <= self.rsi_buy_threshold.value <= 100:
            raise ValueError("RSI buy threshold must be between 0 and 100.")
        if not 0 <= self.adx_buy_threshold.value <= 100:
            raise ValueError("ADX buy threshold must be between 0 and 100.")

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float], max_stake: float,
                            leverage: float, entry_tag: Optional[str], side: str,
                            **kwargs) -> float:
        """
        Calculates the custom stake amount for a trade.
        Args:
            pair: The trading pair (e.g., 'BTC/USDT').
            current_time: The current datetime.
            current_rate: The current price of the pair.
            leverage: The leverage applied to the trade.
            stake_amount: The default stake amount.
            current_profit: The current profit of the trade.
            after_optimization: True if called after hyperopt optimization.
            **kwargs: Additional keyword arguments.
        Returns:
            The calculated stake amount.
        """
        # Implement dynamic stake amount calculation based on risk management principles
        # For example, a fixed percentage of available capital per trade
        # Or a calculation based on ATR for volatility-adjusted position sizing
        # For now, returning the default stake_amount
        calculated_stake = proposed_stake  # Placeholder for actual calculation
        return calculated_stake

    def _calculate_ema(self, dataframe: DataFrame) -> DataFrame:
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=21)
        return dataframe

    def _calculate_rsi(self, dataframe: DataFrame) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def _calculate_adx(self, dataframe: DataFrame) -> DataFrame:
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        return dataframe

    def _calculate_atr(self, dataframe: DataFrame) -> DataFrame:
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        return dataframe

    def _calculate_volume_ma(self, dataframe: DataFrame) -> DataFrame:
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds all indicators to the given dataframe
        """
        try:
            dataframe = self._calculate_ema(dataframe)
            dataframe = self._calculate_rsi(dataframe)
            dataframe = self._calculate_adx(dataframe)
            dataframe = self._calculate_atr(dataframe)
            dataframe = self._calculate_volume_ma(dataframe)

            # Add time filters
            dataframe['hour'] = dataframe['date'].dt.hour
            dataframe['day_of_week'] = dataframe['date'].dt.dayofweek

        except Exception as e:
            self.logger.error(f"Indicator calculation failed: {e}")
            raise

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        self.logger.debug(f"Evaluating entry for {metadata['pair']}")

        dataframe['enter_long'] = 0

        dataframe.loc[
            (qtpylib.crossed_above(dataframe['ema9'], dataframe['ema21'])) &
            (dataframe['rsi'] > self.rsi_buy_threshold.value) &  # Changed to RSI above threshold
            (dataframe['adx'] > self.adx_buy_threshold.value) &
            (dataframe['volume'] > dataframe['volume_ma']),  # Volume confirmation
            'enter_long'
        ] = 1

        return dataframe

    # Hyperopt parameter for timed exit
    timed_exit_candles = DecimalParameter(30, 90, default=50, space="exit", optimize=True, load=True)

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0

        dataframe.loc[
            (dataframe['close'] < dataframe['ema9']) |
            (dataframe['rsi'] < 50),  # RSI drops back
            'exit_long'
        ] = 1

        return dataframe