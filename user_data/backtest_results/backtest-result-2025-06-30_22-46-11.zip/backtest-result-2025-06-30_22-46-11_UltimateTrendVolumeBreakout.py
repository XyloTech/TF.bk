from freqtrade.strategy import IStrategy 
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
 
class UltimateTrendVolumeBreakout(IStrategy):
     # Strategy Configuration 
     timeframe = '5m' 
     informative_timeframe = '1h' 
     
     max_open_trades = 2 
     stoploss = -0.015  # 1.5% 
     trailing_stop = True 
     trailing_stop_positive = 0.015 
     trailing_stop_positive_offset = 0.02 
     minimal_roi = { 
         "0": 0.03, 
         "10": 0.02, 
         "20": 0.01 
     } 
 
     def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame: 
         # Trend Indicators 
         dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20) 
         dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50) 
         dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200) 
 
         # Volume 
         dataframe['volume_ma'] = ta.SMA(dataframe['volume'], timeperiod=20) 
 
         # Breakout points 
         dataframe['swing_high'] = dataframe['high'].rolling(20).max() 
         dataframe['swing_low'] = dataframe['low'].rolling(20).min() 
 
         # RSI for momentum filter 
         dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14) 
 
         return dataframe 
 
     def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame: 
         dataframe.loc[ 
             ( 
                 (dataframe['ema_20'] > dataframe['ema_50']) & 
                 (dataframe['ema_50'] > dataframe['ema_200']) & 
                 (dataframe['close'] > dataframe['swing_high'].shift(1)) & 
                 (dataframe['volume'] > 2 * dataframe['volume_ma']) & 
                 (dataframe['rsi'] > 50) & 
                 (dataframe['rsi'] < 75) 
             ), 
             'enter_long' 
         ] = 1 
 
         return dataframe 
 
     def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame: 
         dataframe.loc[ 
             ( 
                 (dataframe['close'] < dataframe['ema_20']) | 
                 (dataframe['rsi'] > 80) 
             ), 
             'exit_long' 
         ] = 1 
 
         return dataframe