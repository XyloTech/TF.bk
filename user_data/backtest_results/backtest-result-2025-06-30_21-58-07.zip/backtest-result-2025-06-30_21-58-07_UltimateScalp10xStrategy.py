from freqtrade.strategy import IStrategy, merge_informative_pair
from typing import Dict, List, Optional, Tuple
from freqtrade.strategy.interface import ListPairsWithTimeframes # type: ignore
from freqtrade.constants import PairWithTimeframe # type: ignore
from datetime import datetime, timedelta
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas_ta as p_ta
from pandas import DataFrame
from functools import reduce
import numpy as np

class UltimateScalp10xStrategy(IStrategy):
    timeframe = '5m'
    informative_timeframe = '1h'
    
    max_open_trades = 3
    stoploss = -0.05
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    minimal_roi = {
        "0": 0.03,
        "10": 0.02,
        "20": 0.01,
        "30": 0
    }



    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Calculate various indicators
        dataframe['sma_short'] = ta.SMA(dataframe, timeperiod=7)
        dataframe['sma_long'] = ta.SMA(dataframe, timeperiod=14)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] > dataframe['sma_long']) &
            (dataframe['rsi'] < 40)
            , 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] < dataframe['sma_long']) &
            (dataframe['rsi'] > 60)
            , 'exit_long'] = 1
        return dataframe