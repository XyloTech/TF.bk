from freqtrade.strategy import IStrategy, DecimalParameter
from pandas import DataFrame
from datetime import datetime
from typing import Optional
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

import logging

class FixedRiskRewardLossV2(IStrategy):
    """
    FixedRiskRewardLossV2
    This strategy aims to implement a fixed risk-reward ratio with a dynamic stop-loss and take-profit.
    It uses EMA, RSI, ADX, ATR, and Volume MA indicators for entry and exit signals.
    """
    # Strategy interface version - allow new features to be introduced without breaking changes
    # Freqtrade will fail to load strategies that don't match the current interface version.
    strategy_version = 2
    # Strategy Settings
    # Strategy Settings
    timeframe = '1m'
    stake_currency = 'USDT'
    startup_candle_count: int = 30
    minimal_roi = {"0": 0.05}
    stoploss = -0.02

    # Hyperopt parameter for sell signal
    sell_signal_threshold = DecimalParameter(0.01, 0.1, default=0.05, space="sell", optimize=True, load=True)

    # Strategy parameters
    rsi_buy_threshold = DecimalParameter(30, 70, default=70, space='buy', optimize=True, load=True)
    adx_buy_threshold = DecimalParameter(15, 30, default=20, space='buy', optimize=True, load=True)

    # Custom stake sizing
    stake_percentage = DecimalParameter(0.01, 0.1, default=0.05, space="buy", optimize=True, load=True)
    min_account_balance = DecimalParameter(100, 500, default=100, space="buy", optimize=True, load=True)
    max_account_balance = DecimalParameter(10000, 50000, default=20000, space="buy", optimize=True, load=True)

    def __init__(self, config: dict) -> None:
        """
        Initializes the strategy with the given configuration.
        Args:
            config: A dictionary containing the strategy configuration.
        """
        super().__init__(config)
        self.validate_parameters()
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)

    def validate_parameters(self) -> None:
        """
        Validates the strategy parameters to ensure they are within acceptable ranges.
        Raises:
            ValueError: If any parameter is out of its valid range.
        """
        if not 0 <= self.rsi_buy_threshold.value <= 100:
            raise ValueError("RSI buy threshold must be between 0 and 100.")
        if not 0 <= self.adx_buy_threshold.value <= 100:
            raise ValueError("ADX buy threshold must be between 0 and 100.")

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float, 
                            leverage: float, stake_amount: float, current_profit: float, 
                            after_optimization: bool, **kwargs) -> float:
        """
        Calculates the custom stake amount for a trade.
        Args:
            pair: The trading pair (e.g., 'BTC/USDT').
            current_time: The current datetime.
            current_rate: The current price of the pair.
            leverage: The leverage applied to the trade.
            stake_amount: The default stake amount.
            current_profit: The current profit of the trade.
            after_optimization: True if called after hyperopt optimization.
            **kwargs: Additional keyword arguments.
        Returns:
            The calculated stake amount.
        """
        # Implement dynamic stake amount calculation based on risk management principles
        # For example, a fixed percentage of available capital per trade
        # Or a calculation based on ATR for volatility-adjusted position sizing
        # For now, returning the default stake_amount
        calculated_stake = stake_amount  # Placeholder for actual calculation
        return calculated_stake

    def _calculate_ema(self, dataframe: DataFrame) -> DataFrame:
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=21)
        return dataframe

    def _calculate_rsi(self, dataframe: DataFrame) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def _calculate_adx(self, dataframe: DataFrame) -> DataFrame:
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        return dataframe

    def _calculate_atr(self, dataframe: DataFrame) -> DataFrame:
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        return dataframe

    def _calculate_volume_ma(self, dataframe: DataFrame) -> DataFrame:
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds all indicators to the given dataframe
        """
        try:
            dataframe = self._calculate_ema(dataframe)
            dataframe = self._calculate_rsi(dataframe)
            dataframe = self._calculate_adx(dataframe)
            dataframe = self._calculate_atr(dataframe)
            dataframe = self._calculate_volume_ma(dataframe)

            # Add time filters
            dataframe['hour'] = dataframe['date'].dt.hour
            dataframe['day_of_week'] = dataframe['date'].dt.dayofweek

        except Exception as e:
            self.logger.error(f"Indicator calculation failed: {e}")
            raise

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Entry logic based on technical indicators
        Args:
            dataframe: Pandas DataFrame with market data
            metadata: Additional information about the pair
        Returns:
            DataFrame with entry signals
        """
        # Add logging here
        self.logger.debug(f"DEBUG: Entry trend evaluation for {metadata['pair']}")
        self.logger.debug(f"EMA9: {dataframe['ema9'].iloc[-1]}, EMA21: {dataframe['ema21'].iloc[-1]}")
        self.logger.debug(f"RSI: {dataframe['rsi'].iloc[-1]}, ADX: {dataframe['adx'].iloc[-1]}")
        self.logger.debug(f"RSI Buy Threshold: {self.rsi_buy_threshold.value}, ADX Buy Threshold: {self.adx_buy_threshold.value}")
        ema_crossed_above = qtpylib.crossed_above(dataframe['ema9'], dataframe['ema21']).iloc[-1]
        rsi_below_threshold = dataframe['rsi'].iloc[-1] < self.rsi_buy_threshold.value
        adx_above_threshold = dataframe['adx'].iloc[-1] > self.adx_buy_threshold.value

        self.logger.debug(f"Crossed above EMA: {ema_crossed_above}")
        self.logger.debug(f"RSI < Threshold ({dataframe['rsi'].iloc[-1]} < {self.rsi_buy_threshold.value}): {rsi_below_threshold}")
        self.logger.debug(f"ADX > Threshold ({dataframe['adx'].iloc[-1]} > {self.adx_buy_threshold.value}): {adx_above_threshold}")
        self.logger.debug(f"Combined Entry Condition: {ema_crossed_above and rsi_below_threshold and adx_above_threshold}")

        dataframe['enter_long'] = 0
        # Entry long:        
        dataframe.loc[
            (qtpylib.crossed_above(dataframe['ema9'], dataframe['ema21'])) &
            (dataframe['rsi'] < self.rsi_buy_threshold.value) &
            (dataframe['adx'] > self.adx_buy_threshold.value),
            'enter_long'
        ] = 1
        return dataframe

    # Hyperopt parameter for timed exit
    timed_exit_candles = DecimalParameter(10, 100, default=50, space="exit", optimize=True, load=True)

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit logic based on technical indicators
        """
        # Add exit trend logging
        self.logger.debug(f"DEBUG: Exit trend evaluation for {metadata['pair']}")
        self.logger.debug(dataframe[['date', 'close', 'atr', 'ema9']].tail(5))

        # Dynamic ROI Scaling (simple trailing stop based on ATR)
        # This is a placeholder for a more complex dynamic ROI. For now, it's a simple ATR-based exit.
        dataframe.loc[
            (
                (dataframe['close'] < (dataframe['close'].shift(1) - dataframe['atr'] * 0.5))  # Trailing stop based on ATR
            ),
            'exit_long'
        ] = 1

        # Volatility Spike Exit (using ATR)
        dataframe.loc[
            (
                (dataframe['atr'] > dataframe['atr'].rolling(window=10).mean() * 1.5)  # ATR significantly higher than its average
            ),
            'exit_long'
        ] = 1

        # Timed Exit
        # This requires tracking trade duration, which is typically done in custom_exit_signal or by checking trade object.
        # For populate_exit_trend, we can only use candle count.
        dataframe.loc[
            (
                (dataframe['enter_long'].shift(self.timed_exit_candles.value).fillna(0) == 1)  # Exit after N candles
            ),
            'exit_long'
        ] = 1

        # Original exit condition (if still desired, otherwise remove)
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['ema9']) &  # Close below EMA9
                (dataframe['volume'] > 0)
            ),
            'exit_long'
        ] = 1

        return dataframe