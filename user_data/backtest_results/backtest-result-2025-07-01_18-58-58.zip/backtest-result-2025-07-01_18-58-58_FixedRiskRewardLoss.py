# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
# --- Do not remove these libs ---
import numpy as np  # noqa
import pandas as pd  # noqa
from pandas import DataFrame

from freqtrade.strategy import IStrategy, DecimalParameter

# --------------------------------
# Add your lib to import here
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from datetime import datetime
from freqtrade.persistence import Trade
from typing import Optional

import logging
logger = logging.getLogger(__name__)

class FixedRiskRewardLoss(IStrategy):
    """
    This strategy uses custom_stoploss() to enforce a fixed risk/reward ratio
    by first calculating a dynamic initial stoploss via ATR - last negative peak

    After that, we caculate that initial risk and multiply it with an risk_reward_ratio
    Once this is reached, stoploss is set to it and sell signal is enabled

    Also there is a break even ratio. Once this is reached, the stoploss is adjusted to minimize
    losses by setting it to the buy rate + fees.
    """

    INTERFACE_VERSION: int = 3
    custom_info = {
        'risk_reward_ratio': 3.5,
        'set_to_break_even_at_profit': 1,
    }
    use_custom_stoploss = True
    stoploss = -0.9

    # Dynamic stake sizing parameters
    stake_percentage = DecimalParameter(0.01, 0.10, default=0.05, decimals=2, space='strategy', optimize=False)
    min_account_balance = DecimalParameter(100, 500, default=100, decimals=0, space='strategy', optimize=False)
    max_account_balance = DecimalParameter(10000, 50000, default=20000, decimals=0, space='strategy', optimize=False)

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:

        """
            custom_stoploss using a risk/reward ratio
        """
        result = break_even_sl = takeprofit_sl = -1
        custom_info_pair = self.custom_info.get(pair)
        if custom_info_pair is not None:
            # using current_time/open_date directly via custom_info_pair[trade.open_daten]
            # would only work in backtesting/hyperopt.
            # in live/dry-run, we have to search for nearest row before it
            # Use asof to find the last valid observation before or at the open_date_utc
            open_df = custom_info_pair.asof(trade.open_date_utc)

            # trade might be open too long for us to find opening candle
            if(len(open_df) != 1):
                return -1 # won't update current stoploss

            initial_sl_abs = open_df['stoploss_rate']

            # calculate initial stoploss at open_date
            initial_sl = initial_sl_abs/current_rate-1

            # calculate take profit treshold
            # by using the initial risk and multiplying it
            risk_distance = trade.open_rate-initial_sl_abs
            reward_distance = risk_distance*self.custom_info['risk_reward_ratio']
            # take_profit tries to lock in profit once price gets over
            # risk/reward ratio treshold
            take_profit_price_abs = trade.open_rate+reward_distance
            # take_profit gets triggerd at this profit
            take_profit_pct = take_profit_price_abs/trade.open_rate-1

            # break_even tries to set sl at open_rate+fees (0 loss)
            break_even_profit_distance = risk_distance*self.custom_info['set_to_break_even_at_profit']
            # break_even gets triggerd at this profit
            break_even_profit_pct = (break_even_profit_distance+current_rate)/current_rate-1

            result = initial_sl
            if(current_profit >= break_even_profit_pct):
                break_even_sl = (trade.open_rate*(1+trade.fee_open+trade.fee_close) / current_rate)-1
                result = break_even_sl

            if(current_profit >= take_profit_pct):
                takeprofit_sl = take_profit_price_abs/current_rate-1
                result = takeprofit_sl

        return result

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            fiat_currency: str, wallet_balance: float, trade: Optional[Trade],
                            order_type: str, proposed_stake: float, **kwargs) -> float:
        """
        Custom stake amount calculation.
        This method is called before placing an entry order if the stake amount is set to 'custom'
        in the configuration.
        """
        if wallet_balance < self.min_account_balance.value:
            calculated_stake = self.min_account_balance.value * self.stake_percentage.value
        elif wallet_balance > self.max_account_balance.value:
            calculated_stake = self.max_account_balance.value * self.stake_percentage.value
        else:
            calculated_stake = wallet_balance * self.stake_percentage.value

        logger.info(f"Calculated custom stake amount: {calculated_stake} (proposed: {proposed_stake})")
        self.dp.send_msg(f"custom_stake_amount called. Calculated stake: {calculated_stake} (proposed: {proposed_stake}) for pair {pair}")
        return calculated_stake

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['atr'] = ta.ATR(dataframe)
        dataframe['stoploss_rate'] = dataframe['close']-(dataframe['atr']*2)
        self.custom_info[metadata['pair']] = dataframe[['date', 'stoploss_rate']].copy().set_index('date')

        # all "normal" indicators:
        # e.g.
        # dataframe['rsi'] = ta.RSI(dataframe)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Placeholder Strategy: buys when SAR is smaller then candle before
        Based on TA indicators, populates the buy signal for the given dataframe
        :param dataframe: DataFrame
        :return: DataFrame with buy column
        """
        # Always buys if volume is greater than 0 (should always be true for valid candles)
        # Add a simple entry signal based on volume
        # This will always be true for demonstration purposes
        dataframe.loc[dataframe['volume'] > 0, 'enter_long'] = 1
        self.dp.send_msg(f"populate_entry_trend called. enter_long set for {len(dataframe.loc[dataframe['enter_long'] == 1])} rows.")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Placeholder Strategy: does nothing
        Based on TA indicators, populates the sell signal for the given dataframe
        :param dataframe: DataFrame
        :return: DataFrame with buy column
        """

        # Never sells
        dataframe.loc[:, 'exit_long'] = 0
        return dataframe
