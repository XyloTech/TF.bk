from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class AlphaBreakoutV2025(IStrategy):
    # === Strategy Config ===
    timeframe = '5m'
    max_open_trades = 2
    stoploss = -0.015
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02

    minimal_roi = {
        "0": 0.03,
        "10": 0.02,
        "20": 0.015,
        "30": 0.01
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        # ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        # RSI
        dataframe['rsi_5'] = ta.RSI(dataframe, timeperiod=5)
        # EMA
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_100'] = ta.EMA(dataframe, timeperiod=100)
        # Volume moving average
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['adx'] > 25) &
                (dataframe['atr'] > dataframe['atr'].rolling(14).mean()) &
                (dataframe['rsi_5'] > 55) & 
                (dataframe['rsi_5'] < 75) &
                (dataframe['ema_20'] > dataframe['ema_50']) &
                (dataframe['ema_50'] > dataframe['ema_100']) &
                (dataframe['volume'] > dataframe['volume_ma'] * 1.5) &
                (dataframe['volume'] > dataframe['volume'].rolling(5).mean()) &
                (dataframe['date'].dt.hour >= 9) & (dataframe['date'].dt.hour <= 20) &
                (dataframe['volume'] > 0)  # Make sure volume is not 0
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi_5'] < 30)  # Exit when RSI is oversold
            ),
            'exit_long'] = 1
        return dataframe