from freqtrade.strategy import IStrategy, merge_informative_pair
from typing import Dict, List, Optional, Tuple
from freqtrade.strategy.interface import ListPairsWithTimeframes # type: ignore
from freqtrade.constants import PairWithTimeframe # type: ignore
from datetime import datetime, timedelta
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas_ta as p_ta
import pandas as pd
from pandas import DataFrame
from functools import reduce
import numpy as np

class UltimateScalp10xStrategy(IStrategy):
    timeframe = '5m'
    informative_timeframe = '1h'
    
    max_open_trades = 3
    stoploss = -0.04
    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.01
    minimal_roi = {
        "0": 0.02,
        "10": 0.01,
        "20": 0.005,
        "30": 0
    }



    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Calculate various indicators
        dataframe['sma_short'] = ta.SMA(dataframe, timeperiod=5)
        dataframe['sma_long'] = ta.SMA(dataframe, timeperiod=10)

        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_lowerband'] = bollinger['lower']
        dataframe['bb_middleband'] = bollinger['mid']
        dataframe['bb_upperband'] = bollinger['upper']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] > dataframe['sma_long']) &
            (dataframe['close'] < dataframe['bb_lowerband'])
            , 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['sma_short'] < dataframe['sma_long']) &
            (dataframe['close'] > dataframe['bb_upperband'])
            , 'exit_long'] = 1
        return dataframe