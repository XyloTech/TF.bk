import talib.abstract as ta
from freqtrade.strategy import IStrategy, merge_informative_pair
from freqtrade.strategy.interface import ListPairsWithTimeframes
from pandas import DataFrame
from typing import Sequence


class AlphaBreakoutV2025(IStrategy):
    minimal_roi = {
        "0": 0.02,
        "20": 0.01,
        "40": 0
    }

    stoploss = -0.012
    trailing_stop = True
    trailing_stop_positive = 0.006
    trailing_stop_positive_offset = 0.01

    timeframe = '5m'

    def informative_pairs(self) -> ListPairsWithTimeframes:
        return [(pair, '1h') for pair in self.dp.current_whitelist()]

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 5m timeframe indicators
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_100'] = ta.EMA(dataframe, timeperiod=100)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)

        # ADX
        dataframe['adx'] = ta.ADX(dataframe)

        # RSI
        dataframe['rsi_5'] = ta.RSI(dataframe, timeperiod=5)
        dataframe['rsi_14'] = ta.RSI(dataframe, timeperiod=14)

        # ATR
        dataframe['atr'] = ta.ATR(dataframe)

        # Volume moving average
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()

        # MACD Histogram
        macd = ta.MACD(dataframe)
        dataframe['macd_hist'] = macd['macdhist']

        # Swing High (highest high over the last 5 candles)
        dataframe['swing_high'] = dataframe['high'].rolling(window=5).max()

        # 1h timeframe indicators
        if self.config['runmode'].value in ('backtest', 'live', 'dry_run'):
            informative_1h = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe='1h')
            informative_1h['ema_50'] = ta.EMA(informative_1h, timeperiod=50)
            informative_1h['ema_200'] = ta.EMA(informative_1h, timeperiod=200)
            dataframe['trend_1h'] = informative_1h['ema_50'].iloc[-1] > informative_1h['ema_200'].iloc[-1]

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['ema_20'] > dataframe['ema_50']) &
                (dataframe['ema_50'] > dataframe['ema_200']) &
                (dataframe['close'] > dataframe['swing_high'].shift(1)) &
                (dataframe['volume'] > dataframe['volume_ma'] * (1 + dataframe['macd_hist'] / 10)) &
                (dataframe['adx'] > 25) &
                (dataframe['macd_hist'] > 0) &
                (dataframe['rsi_5'] > 55) &
                (dataframe['trend_1h'] == True)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi_5'] < 40) |
                (dataframe['close'] < dataframe['ema_20']) |
                (dataframe['macd_hist'] < 0)
            ),
            'exit_long'] = 1
        return dataframe