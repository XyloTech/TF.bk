from freqtrade.strategy import IStrategy, DecimalParameter
from pandas import DataFrame
from datetime import datetime
from typing import Optional
from freqtrade.persistence import Trade

class FixedRiskRewardLossV2(IStrategy):
    # Strategy Settings
    timeframe = '1m'
    stake_currency = 'USDT'
    startup_candle_count: int = 30
    minimal_roi = {"0": 0.05}
    stoploss = -0.02

    # Hyperopt parameter for sell signal
    sell_signal_threshold = DecimalParameter(0.01, 0.1, default=0.05, space="sell", optimize=True, load=True)

    # Custom stake sizing
    stake_percentage = DecimalParameter(0.01, 0.1, default=0.05, space="buy", optimize=True, load=True)
    min_account_balance = DecimalParameter(100, 500, default=100, space="buy", optimize=True, load=True)
    max_account_balance = DecimalParameter(10000, 50000, default=20000, space="buy", optimize=True, load=True)

    def custom_stake_amount(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        fiat_currency: str,
        wallet_balance: float,
        trade: Optional[Trade],
        order_type: str,
        proposed_stake: float,
        **kwargs
    ) -> float:
        if wallet_balance < self.min_account_balance.value:
            calculated_stake = self.min_account_balance.value * self.stake_percentage.value
        elif wallet_balance > self.max_account_balance.value:
            calculated_stake = self.max_account_balance.value * self.stake_percentage.value
        else:
            calculated_stake = wallet_balance * self.stake_percentage.value

        self.dp.send_msg(f"custom_stake_amount: {calculated_stake:.2f} USDT on {pair}")
        return calculated_stake

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Example: Add a basic indicator
        dataframe['sma'] = dataframe['close'].rolling(window=5).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['close'] > dataframe['sma']) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['sma']) &
                (dataframe['volume'] > 0)
            ),
            'exit_long'
        ] = 1
        return dataframe