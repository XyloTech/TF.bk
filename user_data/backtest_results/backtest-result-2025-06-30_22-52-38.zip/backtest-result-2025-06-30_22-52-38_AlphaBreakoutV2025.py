from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class AlphaBreakoutV2025(IStrategy):
    # === Strategy Config ===
    timeframe = '5m'
    max_open_trades = 2
    stoploss = -0.015
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02

    minimal_roi = {
        "0": 0.03,
        "10": 0.02,
        "20": 0.015,
        "30": 0.01
    }

    def populate_indicators(self, df: DataFrame, metadata: dict) -> DataFrame:
        df['ema_20'] = ta.EMA(df, timeperiod=20)
        df['ema_50'] = ta.EMA(df, timeperiod=50)
        df['ema_200'] = ta.EMA(df, timeperiod=200)

        df['volume_ma'] = ta.SMA(df['volume'], timeperiod=20)

        df['swing_high'] = df['high'].rolling(window=20).max()
        df['swing_low'] = df['low'].rolling(window=20).min()

        df['adx'] = ta.ADX(df, timeperiod=14)
        df['rsi'] = ta.RSI(df, timeperiod=14)

        return df

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df.loc[
            (df['ema_20'] > df['ema_50']) &
            (df['ema_50'] > df['ema_200']) &
            (df['close'] > df['swing_high'].shift(1)) &
            (df['volume'] > 2 * df['volume_ma']) &
            (df['adx'] > 25) &
            (df['rsi'] > 50) & (df['rsi'] < 75),
            'enter_long'
        ] = 1
        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        df.loc[
            (df['close'] < df['ema_20']) |
            (df['rsi'] > 80),
            'exit_long'
        ] = 1
        return df