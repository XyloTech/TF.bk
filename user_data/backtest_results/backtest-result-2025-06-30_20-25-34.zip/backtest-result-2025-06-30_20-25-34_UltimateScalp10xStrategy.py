from freqtrade.strategy import IStrategy, merge_informative_pair
from typing import Dict, List, Optional, Tuple
from freqtrade.strategy.interface import ListPairsWithTimeframes # type: ignore
from freqtrade.constants import PairWithTimeframe # type: ignore
from datetime import datetime, timedelta
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas_ta as p_ta
from pandas import DataFrame
from functools import reduce
import numpy as np

class UltimateScalp10xStrategy(IStrategy):
    # تایم‌فریم‌ها
    timeframe = '1m'
    informative_timeframe = '5m'
    
    # مدیریت ریسک
    stoploss = -0.02
    minimal_roi = {
        "0": 0.02,
        "15": 0.01,
        "30": 0.005
    }

    # مدیریت سرمایه
    leverage_num = 10
    risk_per_trade = 0.03
    cooldown_minutes = 2
    last_exit_time = None

    # تنظیمات حجم و نوسان
    volume_lookback = 20
    volume_zscore_threshold = 2.0
    adx_threshold = 25
    atr_threshold = 0.02

    # هزینه‌های معاملاتی
    slippage = 0.001  # 0.1% slippage
    exchange_fee = 0.001  # 0.1% fee per trade (Binance: 0.1%)

    def informative_pairs(self) -> ListPairsWithTimeframes:
        pairs = self.dp.current_whitelist()
        return ListPairsWithTimeframes([PairWithTimeframe(pair, self.informative_timeframe) for pair in pairs])

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        if dataframe.empty:
            return dataframe

        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0

        dataframe['ema10'] = ta.EMA(dataframe['close'], timeperiod=10) # type: ignore
        dataframe['ema20'] = ta.EMA(dataframe['close'], timeperiod=20) # type: ignore
        dataframe['ema50'] = ta.EMA(dataframe['close'], timeperiod=50) # type: ignore
        dataframe['ema100'] = ta.EMA(dataframe['close'], timeperiod=100) # type: ignore
        dataframe['ema200'] = ta.EMA(dataframe['close'], timeperiod=200) # type: ignore
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=14) # type: ignore
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14) # type: ignore
        # Calculate Supertrend using pandas_ta
        st = p_ta.supertrend(dataframe['high'], dataframe['low'], dataframe['close'], length=10, multiplier=3)
        dataframe['supertrend'] = st['SUPERT_10_3.0']
        dataframe['supertrend_direction'] = st['SUPERTd_10_3.0']

        dataframe['volume_ma'] = ta.SMA(dataframe['volume'], timeperiod=self.volume_lookback) # type: ignore
        dataframe['volume_std'] = ta.STDDEV(dataframe['volume'], timeperiod=self.volume_lookback) # type: ignore
        dataframe['volume_zscore'] = np.where(
            dataframe['volume_std'] > 0,
            (dataframe['volume'] - dataframe['volume_ma']) / dataframe['volume_std'],
            0
        )

        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14) # type: ignore
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14) # type: ignore
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14) # type: ignore

        # تحلیل تایم‌فریم ۵ دقیقه
        informative = self.dp.get_pair_dataframe(
            pair=metadata['pair'],
            timeframe=self.informative_timeframe
        )
        if not informative.empty:
            informative['ema50_5m'] = ta.EMA(informative['close'], timeperiod=50) # type: ignore
            informative['trend_5m'] = (informative['close'] > informative['ema50_5m']).astype(int).replace(0, -1)

            informative['adx_5m'] = ta.ADX(informative, timeperiod=14) # type: ignore
            informative['plus_di_5m'] = ta.PLUS_DI(informative, timeperiod=14) # type: ignore
            informative['minus_di_5m'] = ta.MINUS_DI(informative, timeperiod=14) # type: ignore

            dataframe = merge_informative_pair(
                dataframe, informative,
                self.timeframe, self.informative_timeframe,
                ffill=True
            )

        return dataframe

    def check_cooldown(self):
        if self.last_exit_time:
            elapsed = (datetime.now() - self.last_exit_time).total_seconds() / 60
            return elapsed < self.cooldown_minutes
        return False

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        if self.check_cooldown():
            return dataframe

        required_cols = ['ema10', 'ema50', 'supertrend', 'rsi', 'volume_zscore',
                         'adx', 'plus_di', 'minus_di']
        if not all(col in dataframe.columns for col in required_cols):
            return dataframe

        valid_entries = ~(
            dataframe[required_cols].isnull().any(axis=1)
        )

        conditions_long = [
            dataframe['ema10'] > dataframe['ema50'],
            dataframe['supertrend'] == 1,
            valid_entries
        ]

        conditions_short = [
            dataframe['ema10'] < dataframe['ema50'],
            dataframe['supertrend'] == -1,
            valid_entries
        ]

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_long),
            'enter_long'
        ] = 1

        dataframe.loc[
            reduce(lambda x, y: x & y, conditions_short),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['close'] < dataframe['ema10']) & (dataframe['rsi'] < 40),
            'exit_long'
        ] = 1

        dataframe.loc[
            (dataframe['close'] > dataframe['ema10']) & (dataframe['rsi'] > 60),
            'exit_short'
        ] = 1

        return dataframe