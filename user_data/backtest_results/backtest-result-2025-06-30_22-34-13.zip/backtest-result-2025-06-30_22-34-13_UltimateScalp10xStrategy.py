from freqtrade.strategy import IStrategy, merge_informative_pair
from typing import Dict, List, Optional, Tuple
from freqtrade.strategy.interface import ListPairsWithTimeframes # type: ignore
from freqtrade.constants import PairWithTimeframe # type: ignore
from datetime import datetime, timedelta
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas_ta as p_ta
import pandas as pd
from pandas import DataFrame
from functools import reduce
import numpy as np

class UltimateScalp10xStrategy(IStrategy):
    timeframe = '5m'
    informative_timeframe = '1h'
    
    max_open_trades = 3
    stoploss = -0.015
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.015
    minimal_roi = {
        "0": 0.03,
        "10": 0.02,
        "20": 0.01,
        "30": 0.005
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMAs for trend alignment
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        # Volume indicators
        dataframe['volume_ma'] = ta.SMA(dataframe['volume'], timeperiod=20)
        
        # Swing high/low (20 candles)
        dataframe['swing_high'] = dataframe['high'].rolling(20).max()
        dataframe['swing_low'] = dataframe['low'].rolling(20).min()
        
        # ADX for trend strength
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        
        # RSI for momentum
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Long entry conditions
        dataframe.loc[
            (dataframe['ema_20'] > dataframe['ema_50']) &
            (dataframe['ema_50'] > dataframe['ema_200']) &
            (dataframe['close'] > dataframe['swing_high'].shift(1)) &
            (dataframe['volume'] > 2 * dataframe['volume_ma']) &
            (dataframe['adx'] > 25) &
            (dataframe['rsi'] > 55) &
            (dataframe['rsi'] < 70),
            'enter_long'] = 1
            
        # Short entry conditions (optional)
        dataframe.loc[
            (dataframe['ema_20'] < dataframe['ema_50']) &
            (dataframe['ema_50'] < dataframe['ema_200']) &
            (dataframe['close'] < dataframe['swing_low'].shift(1)) &
            (dataframe['volume'] > 2 * dataframe['volume_ma']) &
            (dataframe['adx'] > 25) &
            (dataframe['rsi'] < 45) &
            (dataframe['rsi'] > 30),
            'enter_short'] = 1
            
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Exit long positions
        dataframe.loc[
            (dataframe['close'] < dataframe['ema_20']) |
            (dataframe['rsi'] > 80),
            'exit_long'] = 1
            
        # Exit short positions
        dataframe.loc[
            (dataframe['close'] > dataframe['ema_20']) |
            (dataframe['rsi'] < 20),
            'exit_short'] = 1
            
        return dataframe