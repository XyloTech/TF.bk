from freqtrade.strategy import IStrategy, DecimalParameter
from pandas import DataFrame
from datetime import datetime
from typing import Optional
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class FixedRiskRewardLossV2(IStrategy):
    # Strategy Settings
    timeframe = '1m'
    stake_currency = 'USDT'
    startup_candle_count: int = 30
    minimal_roi = {"0": 0.05}
    stoploss = -0.02

    # Hyperopt parameter for sell signal
    sell_signal_threshold = DecimalParameter(0.01, 0.1, default=0.05, space="sell", optimize=True, load=True)

    # Custom stake sizing
    stake_percentage = DecimalParameter(0.01, 0.1, default=0.05, space="buy", optimize=True, load=True)
    min_account_balance = DecimalParameter(100, 500, default=100, space="buy", optimize=True, load=True)
    max_account_balance = DecimalParameter(10000, 50000, default=20000, space="buy", optimize=True, load=True)

    def custom_stake_amount(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_stake: float,
        **kwargs
    ) -> float:
        # Safely get parameters that might be missing during hyperoptimization
        fiat_currency = kwargs.get('fiat_currency', 'USDT')  # Default to USDT if not provided
        wallet_balance = kwargs.get('wallet_balance', 0.0)  # Default to 0.0 if not provided
        trade = kwargs.get('trade', None)
        order_type = kwargs.get('order_type', 'limit')  # Default to 'limit' if not provided

        if wallet_balance < self.min_account_balance.value:
            calculated_stake = self.min_account_balance.value * self.stake_percentage.value
        elif wallet_balance > self.max_account_balance.value:
            calculated_stake = self.max_account_balance.value * self.stake_percentage.value
        else:
            calculated_stake = wallet_balance * self.stake_percentage.value

        self.dp.send_msg(f"custom_stake_amount: {calculated_stake:.2f} {fiat_currency} on {pair}")
        return calculated_stake

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=21)

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)

        # ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        # Volume MA
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] < 30) &  # RSI oversold
                (dataframe['adx'] > 20) &  # ADX strong trend
                (dataframe['ema9'] > dataframe['ema21']) &  # EMA crossover confirms direction
                (dataframe['volume'] > dataframe['volume_ma']) &  # Volume spike confirms breakout
                (dataframe['volume'] > 0)  # Ensure volume is not zero
            ),
            'enter_long'
        ] = 1
        return dataframe

    # Hyperopt parameter for timed exit
    timed_exit_candles = DecimalParameter(10, 100, default=50, space="exit", optimize=True, load=True)

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Dynamic ROI Scaling (simple trailing stop based on ATR)
        # This is a placeholder for a more complex dynamic ROI. For now, it's a simple ATR-based exit.
        dataframe.loc[
            (
                (dataframe['close'] < (dataframe['close'].shift(1) - dataframe['atr'] * 0.5))  # Trailing stop based on ATR
            ),
            'exit_long'
        ] = 1

        # Volatility Spike Exit (using ATR)
        dataframe.loc[
            (
                (dataframe['atr'] > dataframe['atr'].rolling(window=10).mean() * 1.5)  # ATR significantly higher than its average
            ),
            'exit_long'
        ] = 1

        # Timed Exit
        # This requires tracking trade duration, which is typically done in custom_exit_signal or by checking trade object.
        # For populate_exit_trend, we can only use candle count.
        dataframe.loc[
            (
                (dataframe['enter_long'].shift(self.timed_exit_candles.value).fillna(0) == 1)  # Exit after N candles
            ),
            'exit_long'
        ] = 1

        # Original exit condition (if still desired, otherwise remove)
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['ema9']) &  # Close below EMA9
                (dataframe['volume'] > 0)
            ),
            'exit_long'
        ] = 1

        return dataframe